# RBAM Part 2 - Relation-Based Argument Mining on Kialo

Course project (CC2, DyCo 26/27): relation discovery and relation-based argument mining (RBAM)
over real argumentative discussions scraped from [Kialo](https://www.kialo.com).

## Task

Given a pair of textual arguments (a claim and a premise), the goal is twofold:

1. **Relation discovery** - decide whether the two arguments are related at all;
2. **Relation classification** - if related, decide whether the relation is a *support* or an
   *attack*.

Following Sahitaj et al. 2024 (KialoPrime), we frame this as a single **ternary classification**
task: `support` / `attack` / `neutral`, solved by fine-tuning a multilingual Transformer encoder.

## Pipeline

```
Kialo API (list 250 most active discussions)
        |
        v
Official export feature (authenticated Selenium download) -> data/debates/*.txt
        |
        v
Parser (utils/kialoParser.py) -> 99,703 (parent, child, support/attack) pairs
        |
        v
Exploratory analysis (analyse.ipynb)
        |
        v
Dataset construction (neutral pairs + discussion-level splits) -> data/dataset.csv (149,232 pairs)
        |
        v
Fine-tuned XLM-RoBERTa-base classifier -> models/xlmr-rbam
```

## 1. Data collection

- The public, unauthenticated `/api/v1/discussions` endpoint is used with a single API call
  (not a page crawl) to list and rank the **250 most active discussions**. Query parameters are
  modeled by the `KialoFilter` / `KialoSort` enums (`utils/kialoEnum.py`); the endpoint is
  documented in `main.ipynb`.
- Each discussion is then downloaded through Kialo's official **export feature**
  (`/export/{id}.txt`, requires login) via Selenium, into `data/debates/` (250 `.txt` files).
  `utils/kialoTool.py` also builds URL slugs from discussion titles (stripping non-alphanumeric
  characters to avoid 404s) and can resume failed downloads by id.

## 2. Parsing (`utils/kialoParser.py`)

The Kialo export format is a numbered outline (`1.2.1. Con:`) whose numbering paths encode the
discussion tree. The parser extracts `(parent, child, relation)` pairs and handles three
corpus-specific quirks:

- **Multilingual labels** - Pro/Con labels appear as `Pro`, `Pour`, `Con`, `Contra`, `Contre`;
  all are mapped to `support`/`attack`. Any other label (`Thesis`, `Question`, multiple-choice
  categories, ...) is a non-argumentative edge and is skipped.
- **Duplicate references** - `-> See 1.1.2.1.1.` placeholders are resolved to the referenced
  node's text, following reference chains. 179 pairs (0.18%) referencing another discussion
  entirely cannot be resolved and are excluded from downstream modelling.
- **Multiple-choice discussions** - 18 discussions are open questions with several candidate
  theses; only the root-level `Question -> Thesis` edges are skipped, the Pro/Con sub-trees are
  parsed normally.

Result: **99,703 argument pairs** (avg. ~399 per discussion), saved to
`data/argument_pairs.csv`.

## 3. Corpus overview

| Language | Discussions | Pairs |
|---|---|---|
| English | 239 | 99,091 |
| German | 3 | 345 |
| Spanish | 4 | 159 |
| Greek | 1 | 50 |
| Slovak | 1 | 23 |
| Swedish | 1 | 20 |
| French | 1 | 15 |

The full structural analysis (parsing quality, language distribution, discussion size, tree
depth, imbalance) is in `analyse.ipynb`.

## 4. Dataset construction

- **Positives** (`support`/`attack`): every (parent, child) pair from the discussion trees; the
  label is given by Kialo's own tree structure.
- **Negatives** (`neutral`): pairs of claims randomly sampled from two *different* discussions,
  same language, following KialoPrime's method.
- **Splits are made by discussion, not by pair**, to avoid train/test leakage. Neutral pairs are
  sampled separately within each split, so no cross-split pair can ever occur.
- English (239 discussions): 70% train / 10% validation / 20% test. The 11 non-English
  discussions (es, de, sk, sv, fr, el) never enter the training set, so the non-English test
  slice measures **zero-shot cross-lingual generalization**.

Final dataset (`data/dataset.csv`): **149,232 pairs**, balanced across relations
(~49.9k support / ~50.2k attack / ~49.7k neutral), split 99,449 train / 18,540 validation /
31,243 test.

## 5. Model

**XLM-RoBERTa-base**, fine-tuned for ternary sequence classification: claim and premise are
concatenated with a separator token, truncated at 256 tokens, trained with AdamW (lr 2e-5,
3 epochs, bf16, effective batch size 32) and cross-entropy loss, tracking accuracy and macro-F1.

We initially selected mDeBERTa-v3-base but hit reproducible numerical instability (NaN
gradients after the first optimizer step, a known DeBERTa-family issue), so we switched to
XLM-RoBERTa-base. A few-shot LLM baseline (Mistral) was considered but not implemented due to
time constraints.

## 6. Results (test set, n = 31,243)

**Overall ternary classification:** accuracy **0.8232**, macro-F1 **0.8223** - about 8 points
below KialoPrime's DeBERTa-base (F1 0.899/0.908), with a training set ~20x smaller and a
different base architecture.

Decomposed into the two sub-problems:

| Sub-task | n | Accuracy |
|---|---|---|
| Relation discovery (related vs. unrelated) | 31,243 | 0.9658 |
| Relation direction (support vs. attack, given discovered as related) | 20,205 | 0.7795 |

Discovery is close to solved; the support/attack direction is the harder part, consistent with
GraphNLI's finding that wider discussion-tree context helps for that sub-task.

Cross-lingual generalization:

| Subset | n | Accuracy | F1 macro |
|---|---|---|---|
| English | 30,521 | 0.8236 | 0.8225 |
| Non-English (zero-shot) | 722 | 0.8075 | 0.8128 |

The drop on unseen languages is only ~1.6 accuracy points despite no non-English training data.

## Kialo's crawling policy

> Crawling Kialo is allowed in accordance with our robots instructions, and you may use our export functionality to download debates for private use. Please don't use other means to monitor or copy any material on Kialo, either manually or through automated means (i.e., scraping), without prior written consent. If you'd like to request consent, please contact support@kialo.com.
>
> - [Kialo Terms of Service](https://www.kialo.com/terms)

Kialo's `robots.txt` (see `kialo robot.txt`) disallows all crawlers except a short allowlist of
known search/preview bots (`Disallow: /` for `User-agent: *`). To stay within this policy, this
project only relies on:

- the public, unauthenticated `/api/v1/discussions` listing endpoint to find and rank
  discussions (a single API call, not a page crawl);
- the official **export feature** to download each discussion, as explicitly permitted above for
  private use.

No other endpoint is scraped in bulk - this stays within the scope of a course assignment
(private, academic use), not redistribution.

## Setup

1. Install dependencies: `poetry install` (includes Selenium, tqdm, pandas, transformers,
   torch, datasets, accelerate, scikit-learn, matplotlib).
2. Fill out a `.env` file with your Kialo credentials - required to log in and use the export
   feature:
   ```
   KIALO_USERNAME=...
   KIALO_PASSWORD=...
   ```
3. A Chromium-based browser is required for Selenium. The reference script uses
   `webdriver.Chrome` (Google Chrome). If you only have Microsoft Edge installed, swap it for
   `webdriver.Edge` (`from selenium.webdriver.edge.options import Options` +
   `webdriver.Edge(options=options)`) - same API, no manual driver download needed (Selenium
   Manager fetches the matching driver automatically).
4. GPU training uses the PyTorch CUDA 12.4 wheels (`pytorch-cu124` source in `pyproject.toml`).

## Project structure

- `main.ipynb` - end-to-end notebook: API reverse-engineering notes, scraping, parsing, dataset
  construction, fine-tuning and evaluation.
- `analyse.ipynb` - structural analysis of the 250-discussion corpus (parsing quality,
  languages, tree statistics).
- `kialo.ipynb` - reference scraping notebook (listing + Selenium login + export download).
- `utils/kialoEnum.py` - `KialoFilter` / `KialoSort` enums for the `/api/v1/discussions`
  endpoint.
- `utils/kialoTool.py` - helpers to list discussions, fetch tags, build export URL slugs and
  download exports.
- `utils/kialoParser.py` - Kialo export parser: tree reconstruction, `-> See` reference
  resolution, multilingual label mapping, pair extraction and CSV (de)serialization.
- `data/` - scraped debates (`debates/`), extracted pairs (`argument_pairs.csv`), the modelling
  dataset (`dataset.csv`) and URL ids (`kialo-url-ids.csv`).
- `research papers/` - related work (KialoPrime, GraphNLI, AM survey, Gorur et al.).

## Inspiration

`kialo.ipynb` is taken from [4mbroise's repository](https://github.com/4mbroise/ADC/blob/main/tool/kialo.ipynb)
and used as inspiration for scraping Kialo discussions.
