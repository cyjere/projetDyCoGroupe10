"""
Enum for query params (sort and filter) of the kialo's 
https://www.kialo.com/api/v1/discussions endpoint

Inspired by 4Ambroise kialo's notebook
"""

from enum import Enum

class KialoSort(Enum):
  RANK_ACTIVITY = "rank_and_latest_activity"
  VIEW          = "view_count"
  LAST_ACTIVITY = "latest_activity"

class KialoFilter(Enum):
  PROMOTED      = "promoted"
  PARTICIPATE   = "participate"
  LAST_ACTIVITY = "latest_activity"
  TAG           = "tag"
  TAG_ALL       = "tag_all"