import requests
import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time
from tqdm import tqdm
import os
import json
import re
from pathlib import Path
from dotenv import load_dotenv

from .kialoEnum import KialoFilter, KialoSort

load_dotenv()

KIALO_BASE_URL = "https://www.kialo.com"
DATA_FOLDER = Path(__file__).resolve().parent.parent / "data"
KIALO_USERNAME = os.environ["KIALO_USERNAME"]
KIALO_PASSWORD = os.environ["KIALO_PASSWORD"]

class KialoTool:

  @classmethod
  def getTags(cls):
    """
    Return a list of avaible discussion tags
    """
    tags = requests.get(f"{KIALO_BASE_URL}/api/v1/discussiontags")
    return [item['tagName'] for item in tags.json()["tags"]]

  @classmethod
  def getDiscussions(cls, filter: KialoFilter, sort: KialoSort, limit=3000):
    """
    Fetches a list of discussions matching the given filter and sort order
    """
    req = f"{KIALO_BASE_URL}/api/v1/discussions?filter=" + str(filter.value) + "&sort=" + str(sort.value) + "&limit=" + str(limit) + "&skip=0"
    response = requests.get(req)
    return response.json()["discussions"]

  @classmethod
  def saveDiscussionsJson(cls, discussions, filename="discussions.json"):
    """
    Saves the raw discussions list (e.g. the result of getDiscussions) as a JSON file in DATA_FOLDER
    """
    DATA_FOLDER.mkdir(parents=True, exist_ok=True)
    with open(DATA_FOLDER / filename, "w", encoding="utf-8") as f:
      json.dump(discussions, f, ensure_ascii=False, indent=2)

  @classmethod
  def discussions2urlID(cls, discussions, export=False):
    """
    Builds each discussion's Kialo URL slug, optionally exporting slugs and tags to a CSV file.
    Unlike the reference script, strips all non-alphanumeric characters, fixing
    404s on titles containing "/" or other punctuation.
    """
    idsUrl = [re.sub(r"[^a-z0-9]+", "-", x["title"].lower()).strip("-")+"-"+str(x["id"]) for x in discussions]
    tags = [x["tags"] for x in discussions]
    if export:
      pd.DataFrame.from_dict({"kialoUrlId" : idsUrl, "tags" : tags}).to_csv(f"{DATA_FOLDER}/kialo-url-ids.csv")

    return idsUrl

  @classmethod
  def downloadDiscussions(cls,disscusionUrlIds):
    """
    Download Kialo's discussions as txt files
    """
    path = os.path.abspath(f"{DATA_FOLDER}/debates")


    prefs = {"download.default_directory": path }
    options = Options()
    options.add_experimental_option("prefs", prefs)
    driver = webdriver.Chrome(options = options)


    driver.get(f"{KIALO_BASE_URL}/login")

    #Login
    id          = driver.find_element(By.ID, "emailOrUsername")
    password    = driver.find_element(By.ID, "password")
    loginButton = driver.find_element(By.CLASS_NAME, "login-form__submit")
    id.send_keys(KIALO_USERNAME)
    password.send_keys(KIALO_PASSWORD)

    loginButton.click()

    myElem = WebDriverWait(driver, 3).until(EC.presence_of_element_located((By.CLASS_NAME, 'home-page-section__header')))


    for urlId in tqdm(disscusionUrlIds):
      driver.get(f"{KIALO_BASE_URL}/export/" + urlId + ".txt")
      time.sleep(1.5)
