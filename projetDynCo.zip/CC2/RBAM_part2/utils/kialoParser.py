import re
from dataclasses import dataclass, asdict
from pathlib import Path

import pandas as pd


DEBATES_FOLDER = Path(__file__).resolve().parent.parent / "data" / "debates"
DATA_FOLDER = DEBATES_FOLDER.parent

LABEL_TO_RELATION = {
    "pro": "support",
    "pour": "support",
    "con": "attack",
    "contra": "attack",
    "contre": "attack",
}

# Matches a node header line like 1.2.1. Con: and captures its path (e.g. 1.2.1) and label(e.g. Con).
HEADER_RE = re.compile(r"^\s*(?P<path>\d+(?:\.\d+)*)\.\s+(?P<label>.+?):\s*$")
# Matches a reference to an existing node and captures the referenced path.
SEE_RE = re.compile(r"^->\s*(?:See|Siehe)\s+(?P<path>\d+(?:\.\d+)*)\.?\s*$")


@dataclass
class ArgumentPair:
    discussion_id: int
    parent_path: str
    parent_text: str
    child_path: str
    child_text: str
    relation: str


def _discussion_id_from_filename(path):
    """
    Extract the discussion id from the file name
    """
    match = re.search(r"-(\d+)\.txt$", path.name)
    return int(match.group(1))


def _parse_nodes(lines):
    """
    Reads header lines (N1.N2...Nk. Label:) and the body text that follows
    each one, stopping naturally once the bibliography section is reached
    ("[1] https://...").
    """
    nodes = {}
    i = 0
    while i < len(lines):
        match = HEADER_RE.match(lines[i])
        if not match:
            i += 1
            continue
        node_path = match.group("path")
        label = match.group("label").strip()
        i += 1
        body_lines = []
        while i < len(lines) and lines[i].strip() != "" and not HEADER_RE.match(lines[i]):
            body_lines.append(lines[i].strip())
            i += 1
        nodes[node_path] = {"label": label, "text": " ".join(body_lines)}
    return nodes


def _resolve_see_references(nodes):
    """
    Replaces "-> See X.Y.Z." placeholders with the referenced node's own text,
    in place.
    """
    for data in nodes.values():
        seen_paths = set()
        while True:
            match = SEE_RE.match(data["text"])
            if not match or match.group("path") in seen_paths:
                break
            seen_paths.add(match.group("path"))
            referenced = nodes.get(match.group("path"))
            if referenced is None:
                break
            data["text"] = referenced["text"]


def parse_debate_file(path):
    """
    Parses one Kialo .txt export into (parent, child, support/attack) pairs.
    Only edges whose child is labelled Pro/Con (in any of the observed
    languages) are kept
    """
    discussion_id = _discussion_id_from_filename(path)
    lines = path.read_text(encoding="utf-8").splitlines()
    nodes = _parse_nodes(lines)
    _resolve_see_references(nodes)

    pairs = []
    for node_path, child in nodes.items():
        if "." not in node_path:
            continue  # root node, no parent to pair it with
        relation = LABEL_TO_RELATION.get(child["label"].lower())
        if relation is None:
            continue
        parent = nodes.get(node_path.rsplit(".", 1)[0])
        if parent is None:
            continue
        pairs.append(ArgumentPair(
            discussion_id=discussion_id,
            parent_path=node_path.rsplit(".", 1)[0],
            parent_text=parent["text"],
            child_path=node_path,
            child_text=child["text"],
            relation=relation,
        ))
    return pairs


def parse_all_debates():
    """
    Loop over all files in debates folder and parse them
    """
    pairs = []
    for file_path in sorted(DEBATES_FOLDER.glob("*.txt")):
        pairs.extend(parse_debate_file(file_path))
    return pairs


def save_pairs_csv(pairs, filename="argument_pairs.csv"):
    """
    Saves the extracted argument pairs to a CSV file in the data folder, for reuse without
    re-parsing the debate files every time.
    """
    DATA_FOLDER.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame([asdict(pair) for pair in pairs])
    df.to_csv(DATA_FOLDER / filename, index=False)


def load_pairs_csv(filename="argument_pairs.csv"):
    """
    Loads previously saved argument pairs back from CSV.
    """
    df = pd.read_csv(DATA_FOLDER / filename)
    return df
